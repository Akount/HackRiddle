import serial
from clarifai import rest
from clarifai.rest import ClarifaiApp
from clarifai.rest import Image as ClImage
from clarifai.rest import InputSearchTerm, OutputSearchTerm, SearchQueryBuilder

app = ClarifaiApp()
#app.models.create('friends')
model = app.models.get('friends')
#model.add_concepts(['pierce'])
#image = ClImage(open('C:/users/chita/Desktop/a.jpg', 'r'))
#image = ClImage(url='https://thumb7.shutterstock.com/display_pic_with_logo/162265/283656011/stock-photo-wooden-little-men-holding-hands-on-wooden-boards-background-symbol-of-friendship-love-and-teamwork-283656011.jpg')
#model.predict([image])
#i=6
#while i<12:
#    app.inputs.create_image_from_filename("C:/users/chita/Desktop/demo/M{}.jpg".format(i), concepts=['marcus'])
#    i+=1
#app.inputs.create_image_from_filename("C:/users/chita/Desktop/demo/P2.jpg", concepts=['pierce'])
#app.inputs.create_image_from_filename("C:/users/chita/Desktop/demo/P3.jpg",  concepts=['pierce'])
#app.inputs.create_image_from_filename("C:/users/chita/Desktop/demo/P4.jpg", concepts=['pierce'])
#app.inputs.create_image_from_filename("C:/users/chita/Desktop/demo/P5.jpg", concepts=['pierce'])

# If you want to positively/negatively train, {"id": "<name>", "value": "true/false"}

#image = ClImage(file_obj=open('C:/users/chita/Desktop/demo/t1.jpg', 'rb'))
# model = app.models.get('friends')
#image=app.inputs.create_image_from_filename("C:/users/chita/Desktop/demo/t1.jpg")
image=app.inputs.create_image_from_filename("C:/Users/akash/Desktop/basic-motion-detection/basic-motion-detection/try.jpg")
#image = ClImage('')
a = (str)(model.predict([image])['outputs'][0]['data']['concepts'])
print a
b = "value"
print a.find(b);
b=(float(a[77:85]))
print (b)
ser = serial.Serial("COM6", 9600)

## loop until the arduino tells us it is ready
while not connected:
    serin = ser.read()
    connected = True

## Tell the arduino to blink!
ser.write("1")

## Wait until the arduino tells us it
## is finished blinking
while ser.read() == '1':
    ser.read()

## close the port and end the program
ser.close()


#(model.predict([image]))